function calkulator(a) {
  document.getElementById("ekran").value =
    document.getElementById("ekran").value + a;

  if (
    a == "+" ||
    a == "-" ||
    a == "*" ||
    a == "/" ||
    a == "f" ||
    a == "n" ||
    a == "%"
  ) {
    if (document.getElementById("pat").value !== "") {
      document.getElementById("t1").value =
        document.getElementById("pat").value;

      document.getElementById("t2").value = "";

      document.getElementById("ekran").value =
        document.getElementById("t1").value + a;
    }
    if (a == "f") {
      document.getElementById("pat").value = 1;
      for (let i = 1; i <= parseInt(document.getElementById("t1").value); i++) {
        document.getElementById("pat").value =
          document.getElementById("pat").value * i;
      }
    }

    document.getElementById("gort").value = a;
  } else if (document.getElementById("gort").value == "") {
    document.getElementById("t1").value =
      document.getElementById("t1").value + a;
  } else {
    document.getElementById("t2").value =
      document.getElementById("t2").value + a;

    let t1 = parseInt(document.getElementById("t1").value);
    let t2 = parseInt(document.getElementById("t2").value);
    let gort = document.getElementById("gort").value;

    if (gort == "+") {
      document.getElementById("pat").value = t1 + t2;
    } else if (gort == "-") {
      document.getElementById("pat").value = t1 - t2;
    } else if (gort == "/") {
      document.getElementById("pat").value = t1 / t2;
    } else if (gort == "*") {
      document.getElementById("pat").value = t1 * t2;
    } else if (gort == "%") {
      document.getElementById("pat").value = (t1 / 100) * t2;
    } else if (gort == "n") {
      if (document.getElementById("pat").value == "")
        document.getElementById("pat").value = 1;

      for (let i = 0; i < t2; i++) {
        document.getElementById("pat").value =
          document.getElementById("pat").value * t1;
      }
    }
  }
  if (a == "<") {
    document.getElementById("ekran").value = "";
    document.getElementById("t1").value = "";
    document.getElementById("t2").value = "";
    document.getElementById("gort").value = "";
    document.getElementById("pat").value = "";
  }
}
